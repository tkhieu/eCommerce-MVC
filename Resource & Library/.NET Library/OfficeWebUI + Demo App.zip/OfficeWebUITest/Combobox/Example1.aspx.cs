﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OfficeWebUITest.Combobox
{
    public partial class Example1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void TestServer(object sender, EventArgs e)
        {

            this.Label1.Text = "You have selected " + this.Combo1.SelectedText + " (" + this.Combo1.SelectedValue + ")";

        }
    }
}
