﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OfficeWebUI.Ribbon;

namespace OfficeWebUITest
{
    public partial class Backstage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            

        }

        protected override void OnInit(EventArgs e)
        {
            // Add backstage Pages at OnInit
            BackstagePage lBackstagePage = new BackstagePage();
            lBackstagePage.Text = "Other page";
            lBackstagePage.ID = "ThePageN3";
            lBackstagePage.UserControl = @"~\BackstageScreens\screen3.ascx";
            this.OfficeRibbon1.ApplicationMenu.BackstagePages.Add(lBackstagePage);

            base.OnInit(e);
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            this.OfficeRibbon1.ApplicationMenuColor = this.TextBox1.Text;
        }
    }
}
