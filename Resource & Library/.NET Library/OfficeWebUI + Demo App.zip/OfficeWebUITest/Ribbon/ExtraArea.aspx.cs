﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OfficeWebUITest
{
    public partial class ExtraArea : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void TestMethod(object sender, EventArgs e)
        {
            this.Label_Sample.Text = "You typed : " + this.TextBox_Search.Text;
        }
    }
}
