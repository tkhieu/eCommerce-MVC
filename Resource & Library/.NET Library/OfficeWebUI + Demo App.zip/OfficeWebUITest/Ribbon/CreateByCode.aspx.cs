﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OfficeWebUITest
{
    public partial class CreateByCode : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected override void OnInit(EventArgs e)
        {
            
            OfficeWebUI.Ribbon.RibbonTab tab = new OfficeWebUI.Ribbon.RibbonTab();
            tab.Text = "hello";
            RibbonContext1.Tabs.Add(tab);

            OfficeWebUI.Ribbon.RibbonGroup group = new OfficeWebUI.Ribbon.RibbonGroup();
            group.Text = "group1";
            tab.Groups.Add(group);

            OfficeWebUI.Ribbon.GroupZone zone = new OfficeWebUI.Ribbon.GroupZone();
            group.Zones.Add(zone);

            OfficeWebUI.Ribbon.MediumItem item = new OfficeWebUI.Ribbon.MediumItem();
            item.Text = "yep";
            item.Tooltip = "<b>Hello world</b><br>You can use HTML inside the tips !";
            item.ImageUrl = "~/Img/application_side.png";
            zone.Content.Add(item);

            item.Click += new EventHandler(item_Click);

            base.OnInit(e);
        }

        void item_Click(object sender, EventArgs e)
        {
            Response.Redirect("yourpage.aspx");
        }

        void lItem_Click(object sender, EventArgs e)
        {
            
        }
    }
}
