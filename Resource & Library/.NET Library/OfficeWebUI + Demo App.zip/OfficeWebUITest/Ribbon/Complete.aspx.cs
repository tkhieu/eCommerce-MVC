﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OfficeWebUITest
{
    public partial class Complete : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            this.OfficeRibbon1.getRibbonItem<OfficeWebUI.Ribbon.MediumItem>("MediumItem4").Text= "youuu";
        }

        protected void testserver(object sender, EventArgs e)
        {
            throw new Exception("ok");
        }

        protected void HideGoupByCode(object sender, EventArgs e)
        {
            RibbonGroupToHide.Visible = false;
        }
    }
}
