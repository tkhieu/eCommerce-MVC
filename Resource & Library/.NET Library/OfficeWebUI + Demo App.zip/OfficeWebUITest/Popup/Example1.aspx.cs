﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OfficeWebUITest.Popup
{
    public partial class Example1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            this.OfficePopup1.Show();
            this.TextBox1.Text = "cool";
        }

        protected void TestOK(object sender, EventArgs e)
        {
            Response.Write(this.TextBox1.Text);
            this.OfficePopup1.Hide();
        }
    }
}
