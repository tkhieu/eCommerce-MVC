﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OfficeWebUITest.Workspace
{
    public partial class Example1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }


        protected void testclick(object sender, EventArgs e)
        {
            this.Label1.Text = "kk";
        }

        protected void test(object sender, EventArgs e)
        {
            this.Workspace1.SelectedAreaID = "Area_Calendrier";
            Label tt = new Label();
            
        }

    }
}
