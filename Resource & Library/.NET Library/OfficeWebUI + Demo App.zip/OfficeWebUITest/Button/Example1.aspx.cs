﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OfficeWebUI;

namespace OfficeWebUITest.Button
{
    public partial class Example1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected override void OnInit(EventArgs e)
        {
            OfficeButton lButton = new OfficeButton();
            lButton.Text = "Created<br/>by code";
            lButton.ID = "ButtonByCode1";
            lButton.DisplayType = ButtonDisplayType.ImageAboveText;
            lButton.ImageUrl = "~/img/docs.png";
            PlaceHolder_ByCode.Controls.Add(lButton);

            OfficeWebUI.Button.MenuItem lMenuItem1 = new OfficeWebUI.Button.MenuItem();
            lMenuItem1.ID = "ButtonMenuItem1";
            lMenuItem1.Text = "Created by code";
            lMenuItem1.ExtraText = "a description here";
            lMenuItem1.ImageUrl = "~/img/bullet_orange.png";
            lMenuItem1.Click += new EventHandler(lMenuItem1_Click);
            lButton.Items.Add(lMenuItem1);

            base.OnInit(e);
        }

        void lMenuItem1_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        protected void test(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }
    }
}
