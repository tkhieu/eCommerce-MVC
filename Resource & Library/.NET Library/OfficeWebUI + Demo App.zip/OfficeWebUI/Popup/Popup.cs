﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OfficeWebUI.Common;
using System.Web.UI.HtmlControls;

namespace OfficeWebUI
{
    [ToolboxData("<{0}:OfficePopup runat=server></{0}:OfficePopup>")]
    public class OfficePopup : ControlAncestor, INamingContainer
    {
        private Panel _panelShadow;
        private Panel _panelPopupHolder;
        private Panel _panelPopup;
        private Panel _panelTitle;
        private Panel _panelClose;
        private Label _closeLabel;
        private Image _closeImage;
        private HtmlGenericControl _frame;
        private Panel _contentContainer;
        private ITemplate _content;
        private Panel _panelFooter;
        private OfficeButton _buttonOk;
        private OfficeButton _buttonCancel;
        

        private String _title = String.Empty;
        private Unit _width = 600;
        private Unit _height = 500;

        public event EventHandler ClickOk;
        public event EventHandler ClickCancel;

        [PersistenceMode(PersistenceMode.InnerProperty),
         TemplateContainer(typeof(TemplateControl)),
         TemplateInstance(TemplateInstance.Single)]
        public ITemplate Content
        {
            get { return this._content; }
            set { this._content = value; }
        }

        public override Unit Width
        {
            get { return this._width; }
            set { this._width = value; }
        }

        public override Unit Height
        {
            get { return this._height; }
            set { this._height = value; }
        }

        public String Title
        {
            get { return this._title; }
            set { this._title = value; }
        }

        public override bool Visible
        {
            get { return (ViewState["Visible"] != null) ? Convert.ToBoolean(ViewState["Visible"]) : false; }
            set { ViewState["Visible"] = value; }
        }

        protected override void OnInit(EventArgs e)
        {
            if (!HttpContext.Current.Items.Contains("OfficeWebUI_Manager"))
                throw new Exception("You must include an OfficeWebUIManager on your page to use OfficeWebUI components");

            //if (HttpContext.Current.Items.Contains("OfficeWebUI_PopupManager"))
            //    throw new Exception("There are more than one OfficeWebUI.OfficePopupManager on the same page, a page can only have one OfficeWebUI.OfficePopupManager, please remove one of them");

            //HttpContext.Current.Items.Add("OfficeWebUI_PopupManager", "true");

            //if (Parent.GetType().ToString().ToLower() != "system.web.ui.htmlcontrols.htmlform")
            //    throw new Exception("The OfficeWebUI.OfficePopupManager must be at the root of page's form");

            Page.ClientScript.RegisterClientScriptResource(this.GetType(), "OfficeWebUI.Resources.Common.Javascript.Popup.js");

            _panelShadow = new Panel();
            _panelShadow.CssClass = "OfficeWebUI_PopupShadow";
            this.Controls.Add(_panelShadow);

            _panelPopupHolder = new Panel();
            _panelPopupHolder.CssClass = "OfficeWebUI_PopupHolder";
            this.Controls.Add(_panelPopupHolder);

            _panelPopup = new Panel();
            _panelPopup.ID = this.ID + "_PanelPopup";
            _panelPopup.CssClass = "OfficeWebUI_Popup _OfficeWebUI_Popup_" + this.ID;
            _panelPopup.Width = this._width;
            _panelPopupHolder.Controls.Add(_panelPopup);

            _panelTitle = new Panel();
            _panelTitle.CssClass = "OfficeWebUI_PopupTitle";
            _panelPopup.Controls.Add(_panelTitle);

            _closeLabel = new Label();
            _closeLabel.CssClass = "PopupTitleSpan";
            _closeLabel.Text = this._title;
            _panelTitle.Controls.Add(_closeLabel);

            _panelClose = new Panel();
            _panelClose.CssClass = "OfficeWebUI_PopupClosePanel";
            _panelTitle.Controls.Add(_panelClose);

            _closeImage = new Image();
            _closeImage.Attributes.Add("onclick", "OfficeWebUI.Popup.Close();");
            _closeImage.ImageUrl = Page.ClientScript.GetWebResourceUrl(this.GetType(), "OfficeWebUI.Resources.Common.Image.Popup_CloseButton.png");
            _panelClose.Controls.Add(_closeImage);


            Panel lPanelClear = new Panel();
            lPanelClear.Style.Add("clear", "both");
            _panelTitle.Controls.Add(lPanelClear);

            _contentContainer = new Panel();
            _contentContainer.CssClass = "OfficeWebUI_PopupContentContainer";
            _contentContainer.Height = this._height;
            _panelPopup.Controls.Add(_contentContainer);

            this._content.InstantiateIn(this._contentContainer);


            _panelFooter = new Panel();
            _panelFooter.CssClass = "OfficeWebUI_PopupFooterPanel";
            _panelPopup.Controls.Add(_panelFooter);

            _buttonOk = new OfficeButton();
            _buttonOk.ID = this.ID + "_ButtonOK";
            _buttonOk.DisplayType = ButtonDisplayType.TextOnly;
            _buttonOk.Text = "Ok";
            _buttonOk.Click += new EventHandler(_buttonOk_Click);
            _panelFooter.Controls.Add(_buttonOk);

            _panelFooter.Controls.Add(new Literal { Text = "&nbsp;" });

            _buttonCancel = new OfficeButton();
            _buttonCancel.ID = this.ID + "_ButtonCancel";
            _buttonCancel.DisplayType = ButtonDisplayType.TextOnly;
            _buttonCancel.Text = "Cancel";
            _buttonCancel.Click += new EventHandler(_buttonCancel_Click);
            _panelFooter.Controls.Add(_buttonCancel);

            //_frame = new HtmlGenericControl("iframe");
            //_frame.Attributes.Add("class", "OfficeWebUI_PopupFrame");
            //_frame.Attributes.Add("frameborder", "0");
            //_frame.Style.Add("height", "100%");
            //_frame.Style.Add("width", "100%");
            //_panelPopup.Controls.Add(_frame);

            

            base.OnInit(e);
        }

        void _buttonCancel_Click(object sender, EventArgs e)
        {
            this.Hide();

            if (this.ClickCancel != null)
            {
                this.ClickCancel(this, new EventArgs());
            }
        }

        void _buttonOk_Click(object sender, EventArgs e)
        {
            if (this.ClickOk != null)
            {
                this.ClickOk(this, new EventArgs());
            }
        }

        protected override void CreateChildControls()
        {
            _panelPopup.Visible = Visible;
            _panelShadow.Visible = Visible;

            if (this.Visible)
            {
                String lScript_Init = "$(document).ready(function() { OfficeWebUI.Popup.InitPopup(\"" + this.ID + "\"); });";
                Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "OfficeWebUI.Popup.InitPopup", lScript_Init, true);

                //Boolean isUsingAjax = false;
                //foreach (Control lctrl in Page.Form.Controls)
                //{
                //    if (lctrl.GetType().ToString() == "System.Web.UI.ScriptManager")
                //        isUsingAjax = true;
                //}

                //if (isUsingAjax)
                //    Page.ClientScript.RegisterStartupScript(this.GetType(), "OfficeWebUI.Popup.InitPopupAjax", "<script>try { Sys.Application.add_load(" + lScript_Init + "); } catch(e) { alert(e); }</script>");
            
            }

            

            base.CreateChildControls();
        }

        public void Show()
        {
            this.Visible = true;
        }

        public void Hide()
        {
            this.Visible = false;
        }
    }
}
