﻿using System;
using System.Web.UI.Design;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OfficeWebUI.Ribbon;
using OfficeWebUI.Common;
using System.Web.UI.Design.WebControls;
using System.ComponentModel.Design;
using System.IO;
using OfficeWebUI.ListView;
using System.Collections.ObjectModel;

namespace OfficeWebUI
{
    [DefaultProperty("Text")]
    [ToolboxData("<{0}:ListView runat=server></{0}:ListView>")]
    [ParseChildren(true)]
    [PersistChildren(false)]
    public class OfficeListView : ControlAncestor, INamingContainer, ICompositeControlDesignerAccessor
    {
        #region Private

        private List<ListViewItem> _items = new List<ListViewItem>();
        private Unit _width = new Unit(200);
        private Unit _height = new Unit(300);
        private ListViewDisplayMode _mode = ListViewDisplayMode.List;

        private Panel _PanelList;

        #endregion

        #region Public

        [PersistenceMode(PersistenceMode.InnerProperty)]
        public List<ListViewItem> Items
        {
            get { return this._items; }
        }

        public override Unit Width
        {
            get { return this._width; }
            set { this._width = value; }
        }

        public override Unit Height
        {
            get { return this._height; }
            set { this._height = value; }
        }

        public ListViewDisplayMode DisplayMode
        {
            get { return this._mode; }
            set { this._mode = value; }
        }

        #endregion

        protected override void OnInit(EventArgs e)
        {
            if (!HttpContext.Current.Items.Contains("OfficeWebUI_Manager"))
                throw new Exception("You must include an OfficeWebUIManager on your page to use OfficeWebUI components");

            Page.ClientScript.RegisterClientScriptResource(this.GetType(), "OfficeWebUI.Resources.Common.Javascript.Ribbon.js");

            _PanelList = new Panel();
            _PanelList.Width = this._width;
            _PanelList.Height = this._height;
            
            this.Controls.Add(_PanelList);


            switch (this._mode)
            {
                case ListViewDisplayMode.List:
                    _PanelList.CssClass = "OfficeWebUI_ListView_List";
                    break;
                case ListViewDisplayMode.Gallery:
                    _PanelList.CssClass = "OfficeWebUI_ListView_Gallery";
                    break;
                default:
                    break;
            }

            DataBind();

            base.OnInit(e);
        }


        public void DataBind()
        {

            foreach (ListViewItem lItem in this._items)
            {
                ControlAncestor lCtrl;
                switch (this._mode)
                {
                    case ListViewDisplayMode.List:
                        lCtrl = new ListViewItemRenderer_List(lItem);
                        break;
                    case ListViewDisplayMode.Gallery:
                        lCtrl = new ListViewItemRenderer_Gallery(lItem);
                        break;
                    default:
                        lCtrl = new ListViewItemRenderer_List(lItem);
                        break;
                }
                _PanelList.Controls.Add(lCtrl);
            }

        }
        

        #region ICompositeControlDesignerAccessor Membres

        public void RecreateChildControls()
        {
            base.ChildControlsCreated = true;
            //EnsureChildControls();
        }

        #endregion
    }

    public class ListView_Designer : CompositeControlDesigner
    {
        private DesignerActionListCollection _actionLists = null;

        /*
        
         * hummm... What you read here is... DRAFT ! 
         * The designer is not ready at all !
         
        */

        public override string GetDesignTimeHtml()
        {
            String lReturn = String.Empty;
            OfficeRibbon lControl = (Component as OfficeRibbon);

            return "<div style='height:60px; padding:5px; border:1px solid #C0C0C0; font-family:Verdana; font-size:8pt;'><b>Ribbon</b> [" + lControl.ID + "]</div>";
        }

        // Do not allow direct resizing of the control
        public override bool AllowResize
        {
            get { return false; }
        }

        // Return a custom ActionList collection
        public override DesignerActionListCollection ActionLists
        {
            get
            {
                if (_actionLists == null)
                {
                    _actionLists = new DesignerActionListCollection();
                    _actionLists.AddRange(base.ActionLists);

                    // Draft for future...
                    //_actionLists.Add(new ActionList(this));
                }
                return _actionLists;
            }
        }


        public class ActionList : DesignerActionList
        {
            private OfficeRibbon_Designer _parent;
            private DesignerActionItemCollection _items;

            // Constructor
            public ActionList(OfficeRibbon_Designer parent)
                : base(parent.Component)
            {
                _parent = parent;

            }

            // Create the ActionItem collection and add one command
            public override DesignerActionItemCollection GetSortedActionItems()
            {
                if (_items == null)
                {
                    _items = new DesignerActionItemCollection();
                    _items.Add(new DesignerActionHeaderItem("Office Web UI"));
                    _items.Add(new DesignerActionMethodItem(this, "ToggleLargeText", "Test for future...", "Office Web UI"));
                  
                }
                return _items;

            }

            

            // ActionList command to change the text size
            private void ToggleLargeText()
            {
                // Get a reference to the parent designer's associated control
                OfficeRibbon ctl = (OfficeRibbon)_parent.Component;

                AboutOfficeWebUI AboutForm = new AboutOfficeWebUI();
                AboutForm.ShowDialog();


                /*
                // Get a reference to the control's LargeText property
                PropertyDescriptor propDesc = TypeDescriptor.GetProperties(ctl)["ApplicationMenuText"];

                // Get the current value of the property
                String v = (String)propDesc.GetValue(ctl);

                // Toggle the property value
                propDesc.SetValue(ctl, "hello world");
                */
            }
        }
    }


}


