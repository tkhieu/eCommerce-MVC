﻿namespace OfficeWebUI
{
    /// <summary>
    /// Supported themes
    /// </summary>
    public enum Theme { Custom, Office2010Silver, Office2010Blue }

    /// <summary>
    /// Supported types of Ribbon menus
    /// </summary>
    public enum ApplicationMenuType { Default, Backstage, None }

    /// <summary>
    /// Supported types of buttons
    /// </summary>
    public enum ButtonDisplayType { ImageAboveText, ImageBeforeText, TextOnly, ImageOnly }

    public enum DocumentDirection { LTR, RTL }

    public enum ListViewDisplayMode { List, Gallery }
}